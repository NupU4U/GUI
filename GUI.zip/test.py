import tkinter as tk

def update_listbox(*args):
    search_term = search_var.get()
    listbox.delete(0, tk.END)  # Clear the listbox

    # Iterate over the items and add matching items to the listbox
    for item in items:
        if search_term.lower() in item.lower():
            listbox.insert(tk.END, item)

# Create a Tkinter window
window = tk.Tk()

# Create a search entry widget
search_var = tk.StringVar()
search_var.trace("w", update_listbox)  # Call update_listbox() whenever the search entry changes
search_entry = tk.Entry(window, textvariable=search_var)
search_entry.pack()

# Create a listbox widget
listbox = tk.Listbox(window)
listbox.pack()

# Populate the listbox with items
items = ["Apple", "Banana", "Cherry", "Durian", "Elderberry", "Fig"]
for item in items:
    listbox.insert(tk.END, item)

# Start the Tkinter event loop
window.mainloop()
