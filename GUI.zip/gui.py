from imports import *
from button_front_page import *
from gif import *
import customtkinter

def change_state(mybutton):
    if mybutton['state'] == 'disabled':
        mybutton.configure(state='normal')
    else:
        mybutton.configure(state='disabled')
def upload_excel():
    global data_list
    global supplier_consolidated
    # Open file dialog to select the Excel file
    file_path = filedialog.askopenfilename(filetypes=[("Excel Files", "*.xlsx")])
    if file_path:
        # Load the workbook
        workbook = openpyxl.load_workbook(file_path)

        # Select the active sheet
        sheet = workbook.active

        # Retrieve the column headings
        supplier_consolidated = [cell.value for cell in sheet[1]]

        # Store the data column-wise
        column_data = []
        for column in sheet.iter_cols(min_row=2, values_only=True):
            column_data.append(list(column))

        # Create a list of tuples with column headings and data
        data_list = list(zip(supplier_consolidated, column_data))
        # return data_list
        # Print the data
        
        # btn_next_1.forget()
        btn_next.place(x=100,y=270)
        # option_menu_file.place_forget()
        # option_menu_supplier.place(x=155,y=155)
        change_state(btn_upload)
        change_state(option_menu_file)
        messagebox.showinfo("Tool Message", "Upload Successful!\n\n Please press Next")
        # for column_heading, column_values in data_list:
        #     print(f'{column_heading}: {column_values}')
        # print(supplier_consolidated)
        # print(data_list)
def show_type_of_files():
    global selected_file_type 
    btn_next.place_forget()
    btn_upload.place_forget()
    option_menu_file.place_forget()
    if selected_file_type == "Supplier":
        option_menu_supplier.place(x=25,y=150)
    btn_next1.place(x = 25, y =202 )
    btn_back1.place(x = 100 , y = 270)
    def enable_button2(*args):
        global selected_file
        if var_file.get():
            btn_next1.config(state=tk.NORMAL)
        else:
            btn_next1.config(state=tk.DISABLED)
        selected_file = var_file.get() 
        # print(selected_file)   
    var_file.trace("w", enable_button2)
        
def back_to_generate_other_file():
    global mappings, mappings_supplier,mappings_supplier_address,mappings_supplier_site ,bool1
    global selected_file 
    # print (selected_file)
    if bool1:  
        if selected_file == "Transform Supplier Profile":
            mappings_supplier=mappings.copy()
            # print(mappings_supplier)
        elif selected_file == "Transform Supplier Address Profile":
            mappings_supplier_address = mappings.copy()
            # print(mappings_supplier_address)

        elif selected_file == "Transform Supplier Site Profile":
            mappings_supplier_site = mappings.copy()
            # print(mappings_supplier_site)
    bool1 = False
    mappings.clear() 
    print(mappings_supplier)

    description_mapping.place_forget()
    heading_label.place_forget()
    heading_label1.place_forget()
    frame_mapping.place_forget()
    frame.place(x=610, y=245)
    frame.bind("<Configure>", update_frame_position)
    option_menu_supplier.place(x=25,y=150)
    btn_next1.place(x = 25, y =202 )
    btn_back1.place(x = 100 , y = 270)
    def enable_button1(*args):
    # Check if an option is selected
        if var_file.get():
            btn_next1.config(state=tk.NORMAL)
        else:
            btn_next1.config(state=tk.DISABLED)
        print(mappings_supplier)

        # print( selected_file)
        # print(mappings)
    var_file.trace("w", enable_button1)


def back1():

    option_menu_supplier.place_forget()
    btn_next1.place_forget()
    btn_back1.place_forget()
    supplier_consolidated.clear()
    data_list.clear()
    btn_upload.place(x= 25, y = 202)
    option_menu_file.place(x= 25, y = 150)
    change_state(option_menu_file)

def home():
    global selected_file
    global selected_file_type
    global mappings
    selected_file = None
    selected_file_type= None
    mappings.clear() 
    description_mapping.place_forget()
    heading_label.place_forget()
    heading_label1.place_forget()
    frame_mapping.place_forget()
    frame.place(x=610, y=245)
    frame.bind("<Configure>", update_frame_position)
    supplier_consolidated.clear()
    data_list.clear()
    btn_upload.place(x= 25, y = 202)
    option_menu_file.place(x= 25, y = 150)
    change_state(option_menu_file)
    
def show_mapping_window():
    global bool1, mappings_supplier_address, mappings_supplier, mappings_supplier_site, mappings, selected_file
    # print(mappings_supplier)
    bool1 = True
    def generate_mapped_excel_file(mapped_headers, data_list, list_type):
        file_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx")])
        if file_path:
            workbook = openpyxl.Workbook()
            sheet = workbook.active

            # Write the headers to the first row
            headers = list_type
            sheet.append(headers)
            target_column = 'Import Action'
            column_index = list_type.index(target_column) +1
            # print(len(data_list[1]))
            for count in range (len(data_list[0][1])) :
                sheet.cell(row=count + 2, column=column_index, value="Create")
            # Write the column data
            for column_heading, column_values in data_list:
                if column_heading in mapped_headers:
                    target_column = mapped_headers[column_heading]  # Get the mapped target column
                    column_index = list_type.index(target_column) + 1  # Get the index of the target column
                    for i, value in enumerate(column_values):
                        sheet.cell(row=i + 2, column=column_index, value=value)  # Write the value to the specific column

            # Save the workbook as an XLSX file
            workbook.save(file_path)

    
#Frame
    change_state(btn_next1)

    frame.place_forget()
    frame_mapping.place(x=0,y=0)
    # frame_mapping.rowconfigure(0, weight=1)
    # frame_mapping.columnconfigure(0, weight=1)
    # update frame position 
    def update_frame_mapping_position(event):
        frame_mapping.place(relx=0.5, rely=0.5, anchor='center')

    frame_mapping.bind("<Configure>", update_frame_mapping_position)
# File to Generate 

    custom_font = font.Font(size=12)
    if selected_file == "Transform Supplier Profile":
        other_list = supplier_colums[:]
        # print (mappings_supplier)
        mappings=mappings_supplier
    elif selected_file == "Transform Supplier Address Profile":
        other_list = supplier_address[:]
        mappings=mappings_supplier_address
    elif selected_file == "Transform Supplier Site Profile":
        mappings=mappings_supplier_site        
        other_list = supplier_site_data[:]

    generating_list = other_list[:]
#Drop function
    def start_drag(event):
        index = listbox_supplier_consolidated.nearest(event.y)
        dragged_value = listbox_supplier_consolidated.get(index)
        listbox_supplier_consolidated.selection_set(index)
        listbox_supplier_consolidated._drag_data = dragged_value
        listbox_supplier_consolidated._drag_index = index
        listbox_supplier_consolidated.bind("<B1-Motion>", on_drag)

    def on_drag(event):
        listbox_supplier_consolidated.selection_clear(0, tk.END)
        index = listbox_supplier_consolidated.nearest(event.y)
        listbox_supplier_consolidated.selection_set(listbox_supplier_consolidated._drag_index, index)

    def on_drop(event):
        
        data = listbox_supplier_consolidated._drag_data
        index = listbox_other_file.nearest(event.y)
        destination_value = listbox_other_file.get(index)
        # print (data)
        # if (destination_value == "CLEAR MAPPING FOR THIS" and (data in mappings) ):
        #     del mappings[data]
            # print(mappings)
        # elif ( destination_value != "CLEAR MAPPING FOR THIS" ):
        mappings[data] = destination_value
            # print(mappings)
        # else: 
        #     return
        # Clean up
        listbox_supplier_consolidated.unbind("<B1-Motion>")
        listbox_supplier_consolidated.selection_clear(0, tk.END)
        listbox_supplier_consolidated._drag_data = None
        listbox_supplier_consolidated._drag_index = None
        update_mappings_display()
        
    def clear_mapping_for_selected():
        data= listbox_supplier_consolidated._drag_data
        if (data in mappings):
            del mappings[data]
        update_mappings_display()

#Listboxes
    # Central MAPPING description-
    def update_mappings_display():
        central_listbox.delete(0, tk.END)  # Clear previous mappings
        # print ( "I am here" )
        for element1, element2 in mappings.items():
            mapping_text1 = f"{element1} => {element2}"
            central_listbox.insert(tk.END,mapping_text1) 
    description_mapping.place(x=0 , y=-323)

    central_listbox = tk.Listbox(frame_mapping, height=20,width= 40,exportselection=False,bd=5)
    central_listbox.place(x=0, y=-100)

    central_listbox_scrollbar = tk.Scrollbar(central_listbox)
    central_listbox_scrollbar.place(relx=1,rely=0,relheight=1,anchor=tk.NE)
    central_listbox_scrollbar.configure(command=central_listbox.yview)

    def update_description_mapping(event):
        description_mapping.place(relx=0.5, rely=0.5, anchor='center')
    description_mapping.bind("<Configure>", update_description_mapping)

    def update_central_listbox_position(event):
            central_listbox.place(relx=0.5, rely=0.5, anchor='center')
    central_listbox.bind("<Configure>", update_central_listbox_position)

    # listbox_supplier_consolidated

    heading_label.place(x=-409 , y=-274)

    heading_label1.place(x=400, y=-274)
    
    listbox_supplier_consolidated = tk.Listbox(frame_mapping, height=31,width= 46,exportselection=False,font = custom_font,bd=5,borderwidth=5)
    listbox_supplier_consolidated.place(x=-408, y=34)

    scrollbar_supplier_consolidated = tk.Scrollbar(listbox_supplier_consolidated)
    scrollbar_supplier_consolidated.place(relx=1,rely=0,relheight=1,anchor=tk.NE)

    supplier_consolidated_list = supplier_consolidated[:]
    for item in supplier_consolidated_list:
                listbox_supplier_consolidated.insert(tk.END, item )
    
    listbox_supplier_consolidated.configure(yscrollcommand=scrollbar_supplier_consolidated.set)
    scrollbar_supplier_consolidated.configure(command=listbox_supplier_consolidated.yview)
    frame_mapping.bind("<Configure>",frame_mapping.place(relx=0.5, rely=0.5, anchor='center'))
    
    # Other ListBox
    listbox_other_file = tk.Listbox(frame_mapping, height=29,width= 46,exportselection=False,font = custom_font,bd=5)
    listbox_other_file.place(x=400, y=50)

    scrollbar_other_file = tk.Scrollbar(listbox_other_file)
    scrollbar_other_file.place(relx=1,rely=0,relheight=1,anchor=tk.NE)
    # "Generate Supplier File", "Generate Address File", "Generate Supplier Site File"
    
    for item in other_list:
                listbox_other_file.insert(tk.END, item )
    
    listbox_other_file.configure(yscrollcommand=scrollbar_other_file.set)
    scrollbar_other_file.configure(command=listbox_other_file.yview)
    # frame_mapping.bind("<Configure>",frame_mapping.place(relx=0.5, rely=0.5, anchor='center'))
    #Allignment of list boxes 
    def update_listbox1_position(event):
        listbox_supplier_consolidated.place(relx=0.5, rely=0.5, anchor='center')

    def update_listbox1_heading_position(event):
        heading_label.place(relx=0.5, rely=0.5, anchor='center')

    def update_listbox2_position(event):
        listbox_other_file.place(relx=0.5, rely=0.5, anchor='center')

    def update_listbox2_heading_position(event):
        heading_label1.place(relx=0.5, rely=0.5, anchor='center')
           
    listbox_supplier_consolidated.bind("<Configure>", update_listbox1_position)
    heading_label.bind("<Configure>", update_listbox1_heading_position)
    listbox_other_file.bind("<Configure>", update_listbox2_position)
    heading_label1.bind("<Configure>", update_listbox2_heading_position)

#Drag and Map    
    listbox_supplier_consolidated.bind("<Button-1>", start_drag)
    listbox_other_file.bind("<Button-1>", on_drop)
    update_mappings_display()

    def clear_mapping(): 
        mappings.clear()
        update_mappings_display()
        
#Buttons
    # clear mapping button
    btn_clear_mapping = bttn(frame_mapping, 0, 130, "Clear all the mappings", '#000000', '#E5E8E8','#525252',clear_mapping,'normal',None,2,27,("Calibri Light", 10))
    def update_clear_mapping_button_position(event):
        btn_clear_mapping.place(relx=0.5, rely=0.5, anchor='center')
    btn_clear_mapping.bind("<Configure>", update_clear_mapping_button_position)
    # heading_label1 = tk.Label(window, text="Target",bg='#012E5F',fg="#FFFFFF", font=("Arial", 14,"bold"),height=1,width=35)

    # clear mapping for seletected button
    btn_clear_mappin_for_selected = bttn(frame_mapping, 400, -250, "Clear Mapping For This", '#FFFFFF', '#000000','#EEF2F7',clear_mapping_for_selected,'normal',None,1,39,("Calibri Light", 14,"bold"))
    def update_clear_mapping_for_selected_button_position(event):
        btn_clear_mappin_for_selected.place(relx=0.5, rely=0.5, anchor='center')
    btn_clear_mappin_for_selected.bind("<Configure>", update_clear_mapping_for_selected_button_position)
    # Export excell file button 
    btn_generate_xlsx = bttn(frame_mapping, 0, 190, "Generate Excel File", '#000000', '#E5E8E8','#525252',lambda: generate_mapped_excel_file(mappings, data_list, generating_list),'normal',photo,30,190,("Calibri Light", 10))
    def update_genrate_excel_button_position(event):
        btn_generate_xlsx.place(relx=0.5, rely=0.5, anchor='center')
    btn_generate_xlsx.bind("<Configure>", update_genrate_excel_button_position)
    #back button page 3 
    btn_generate_other_file  = bttn(frame_mapping, 0, 250, "Generate Other File", '#000000', '#E5E8E8','#525252',back_to_generate_other_file,'normal',None,2,27,("Calibri Light", 10))
    def update_generate_other_file_buttin_posiiton(event):
        btn_generate_other_file.place(relx=0.5, rely=0.5, anchor='center')
    btn_generate_other_file.bind("<Configure>", update_generate_other_file_buttin_posiiton)
    #btn home
    # btn_home  = bttn(frame_mapping, 0, 310, "Home", '#000000', '#E5E8E8','#525252',home,'normal',None,2,20,("Calibri Light", 10))
    # def update_other_file_button_positon(event):
    #     btn_home.place(relx=0.5, rely=0.5, anchor='center')
    # btn_home.bind("<Configure>", update_other_file_button_positon)
    # print(mappings)

# Create the main window
window = tk.Tk()
bool1 = False
mappings_supplier = {}
mappings_supplier_address = {}
mappings_supplier_site ={}
mappings = {}
selected_file = None
selected_file_type = None
def enable_button(*args):
    global selected_file_type
    # Check if an option is selected
    if var_type_of_file.get():
        btn_upload.config(state=tk.NORMAL)
    else:
        btn_upload.config(state=tk.DISABLED)
    selected_file_type = var_type_of_file.get()

window.title("EY DATA CONVERSION TOOL")
window.geometry("400x300")
window.minsize(400, 300)

# UI elements

#images

#background
background_image = Image.open("backgroud.jpg")
custom_width = window.winfo_screenwidth()
custom_height = window.winfo_screenheight()
resized_image = background_image.resize((custom_width, custom_height))
background_image = ImageTk.PhotoImage(resized_image)
background_label = tk.Label(window, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# frame
frame = customtkinter.CTkFrame(window, width=310, height=310,corner_radius=15, border_width=0 ,fg_color='#DEDEDE',bg_color='#3a3a3a')
frame.place(x=0, y=0)
# frame.rowconfigure(0, weight=1)
# frame.columnconfigure(0, weight=1)
frame_mapping = customtkinter.CTkFrame(window, width=1300, height=700,corner_radius=15, border_width=0 ,fg_color='#DEDEDE',bg_color='#3a3a3a')
frame_mapping.place_forget()

#EY_logo
image_ey = Image.open("ey-logo-black.jpg")
image_ey = image_ey.resize((60, 45))  # Resize the image if needed
image_eyy = ImageTk.PhotoImage(image_ey)
label_ey = tk.Label(frame, image=image_eyy)
label_ey.place(x=120,y=35) 

#Excel logo
image = Image.open("Microsoft_Office_Excel.png")
image = image.resize((20, 20))  # Resize the image if needed
photo = ImageTk.PhotoImage(image)

#labels 

lbl_file_gen_tool = tk.Label(frame, text="Oracle Cloud FBDI \nFile Generator", bg='#DEDEDE', fg="Black",  font=("Arial", 15,"bold"))
lbl_file_gen_tool.place(x= 60,y=90)
description_mapping = tk.Label(window, text="""Kindly map the fields from source file to Target FBDI file and Click on generate button  """,bg='#012E5F',fg="#FFFFFF", font=("Arial", 10),width=162)
description_mapping.place_forget()
heading_label = tk.Label(window, text="Source",bg='#012E5F',fg="#FFFFFF", font=("Arial", 14,"bold"),height=1,width=35)
heading_label.place_forget()
heading_label1 = tk.Label(window, text="Target",bg='#012E5F',fg="#FFFFFF", font=("Arial", 14,"bold"),height=1,width=35)
heading_label.place_forget()
#buttons 
btn_upload= bttn(frame, 25, 220, "Upload Excel File  ", '#FDFEFE', '#000000','#E5E8E8', upload_excel,'disabled',photo,30,255,("Calibri Light", 10))
btn_next =bttn(frame, 25, 270, "Next", '#808080', '#FDFEFE','#17202A', show_type_of_files,'normal',"" ,1,10,("Calibri Light", 11,'bold'))
btn_next1 =bttn(frame, 30, 202, "Next",'black', '#FFFFFF',"#525252", show_mapping_window,'disabled',None,1,28,("Calibri Light", 11,'bold'))
btn_back1 =bttn(frame, 25, 270, "Back", '#2C3E50', '#FDFEFE','#17202A', back1,'normal',None ,1,10,("Calibri Light", 11,'bold'))
btn_next1.place_forget()
btn_back1.place_forget()
btn_next.place_forget()

# Function to update frame position when the window is resized
def update_frame_position(event):
    frame.place(relx=0.5, rely=0.5, anchor='center')
    
# def update_label_position(event):
#     label.place(relx=0.5, rely=0.5, anchor='center')
# Bind the update_frame_position function to window resize even

#Option menu's 

#file_type
var_type_of_file = tk.StringVar(window)
var_type_of_file.set("Upload Process")
options = ["Supplier", "Customer"]
option_menu_file = opt_menu(frame, 25, 170, 1, 1, var_type_of_file ,options,  '#FDFEFE', '#000000','#E5E8E8', None,'normal',40,37 )
var_type_of_file.trace("w", enable_button)

#Supplier file 
var_file = tk.StringVar(window)
var_file.set("Select File Type")
options_supplier = ["Transform Supplier Profile", "Transform Supplier Address Profile", "Transform Supplier Site Profile"]
option_menu_supplier = opt_menu(frame, 25, 150, 1, 1, var_file,options_supplier,  '#FDFEFE', '#000000','#E5E8E8', None,'normal', 40 ,37 )
option_menu_supplier.place_forget()

window.grid_rowconfigure(0, weight=1)
window.grid_rowconfigure(5, weight=1)
window.grid_columnconfigure(0, weight=1)
window.grid_columnconfigure(2, weight=1)
# Center the window in the grid

window.update_idletasks()
window_width = window.winfo_width()
window_height = window.winfo_height()
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2
window.geometry(f"{window_width}x{window_height}+{x}+{y}")
frame.bind("<Configure>", update_frame_position)
# label.bind("<Configure>", update_label_position)
# Start the main event loop
window.mainloop()
