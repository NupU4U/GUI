# frame.grid(row=0, column=0, padx=1, pady=1)


# btn_upload= bttn(window, 613, 242, 2, 2, "Upload Excel File  ", '#ffcc66', '#141414', upload_excel,'normal',photo,150,306)

# btn_next =bttn(window, 613, 394, 1, 1, " Next ", '#ffcc66', '#141414', show_mapping_window,'disabled',None ,10,25)
# option_menu = opt_menu(window, 766, 394, 1, 1, "Selelct the type of\n File to Generate",options,  '#ffcc66', '#141414', None,'normal' )


# variable = tk.StringVar(window)
# variable.set("Select File Type")

# option_menu = tk.OptionMenu(window, variable, *options)
# option_menu.grid(row=3, column=0, columnspan=3, sticky="n")

# btn_next = tk.Button(window, text="Next", command=show_mapping_window, state=tk.DISABLED)
# btn_next.grid(row=4, column=0, sticky="e")
#  opt_menu(window, row, column, rowspan, columnspan, text, options, bcolor, fcolor, cmd,statee)

# image_r = Image.open("rounded_page1.png")
# rounded = ImageTk.PhotoImage(image_r)
# # Create a label with the image
# label = tk.Label(window, image=rounded, borderwidth= 0 )
# label.place(x=100,y=100)


    # global variable
    # selected_option = variable.get()

    # print (selected_option,": this is selected ") 
    # def generate_mapped_excel_file(mapped_headers, data_list, list_type):
    #     # print (data_list)
    #         # Create a new workbook
    #     file_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx")])
    #     if file_path:
    #         workbook = openpyxl.Workbook()
    #         sheet = workbook.active

    #         # Write the headers to the first row
    #         headers = list_type
    #         sheet.append(headers)

    #         # Write the column data
    #         for column_heading, column_values in data_list:
    #             if (column_heading in mapped_headers):
    #                 target_column = mapped_headers[column_heading]  # Get the mapped target column
    #                 column_index = list_type.index(target_column) + 1  # Get the index of the target column
    #                 for i, value in enumerate(column_values):
    #                     sheet.cell(row=i+2, column=column_index, value=value)  # Write the value to the specific column
            
    #         workbook.save(file_path)
    #         # Save the workbook as an XLSX file
    #         lbl_saved_successfully.config(text="Excel file saved successfully.")  # Update the label text

    # if selected_option == "Generate Supplier File":
    #     # btn_next_1.config(state=tk.DISABLED)
    #     # Open mapping window for Option 1
    #     option_menu_supplier.place_forget()
    #     btn_next_2.place_forget()  
    #     lbl_uploaded.place_forget()
    #     lbl_title.place_forget()
    #     frame.place_forget()
    #     btn_upload.place_forget()
    #     # Configure row and column to expand and fill available space
    #     window.grid_rowconfigure(0, weight=1)
    #     window.grid_rowconfigure(5, weight=1)
    #     window.grid_columnconfigure(0, weight=1)
    #     window.grid_columnconfigure(2, weight=1)

    #     # Create UI elements for mapping
    #     lbl_option1 = tk.Label(window, text="Mapping to Generate Supplier File ")
    #     lbl_option1.place(x=660,y=20)
    #     # Store the mappings in a dictionary
    #     mappings = {}
        
    #     def populate_listbox(my_list,listboxx):
    #         # Clear the listbox
    #         listboxx.delete(1.0, tk.END)

    #         # Populate the listbox with elements from the list
    #         for item in my_list:
    #                 listboxx.insert(tk.END, item + "\n")

    #     frame_consolidated = tk.Frame(window, width=400, height=600)
    #     frame_consolidated.place(x = -350, y =0)
        
    #     # Frame - ListBox Consolidated                    

    #     listbox_supplier_consolidated = tk.Listbox(frame_consolidated)
    #     listbox_supplier_consolidated.place(x=0, y=0, relwidth=1,relheight=1)

    #     # Create a scrollbar widget
    #     scrollbar_supplier_consolidated = tk.Scrollbar(frame_consolidated)
    #     scrollbar_supplier_consolidated.place(relx=1,rely=0,relheight=1,anchor=tk.NE)

    #     # Configure the scrollbar to scroll the listbox
    #     supplier_consolidated_list = supplier_consolidated[:]
    #     for item in supplier_consolidated_list:
    #                 listbox_supplier_consolidated.insert(tk.END, item )
        
    #     listbox_supplier_consolidated.configure(yscrollcommand=scrollbar_supplier_consolidated.set)
    #     scrollbar_supplier_consolidated.configure(command=listbox_supplier_consolidated.yview)
    #     frame_consolidated.bind("<Configure>",frame_consolidated.place(relx=0.5, rely=0.5, anchor='center'))
    #     ###########
    #     # Frame - ListBox Supplier                    
    #     ###########
    #     frame_supplier = tk.Frame(window, width=400, height=600)
    #     frame_supplier.place(x = 350, y =0)

    #     listbox_supplier = tk.Listbox(frame_supplier)
    #     listbox_supplier.place(x=0, y=0, relwidth=1,relheight=1)

    #     # Create a scrollbar widget
    #     scrollbar_supplier = tk.Scrollbar(frame_supplier)
    #     scrollbar_supplier.place(relx=1,rely=0,relheight=1,anchor=tk.NE)

    #     # Configure the scrollbar to scroll the listbox

    #     supplier_list = supplier_colums[:]
    #     for item in supplier_list:
    #                 listbox_supplier.insert(tk.END, item )
        
    #     listbox_supplier.configure(yscrollcommand=scrollbar_supplier.set)
    #     scrollbar_supplier.configure(command=listbox_supplier.yview)
    #     frame_supplier.bind("<Configure>",frame_supplier.place(relx=0.5, rely=0.5, anchor='center'))  

    #     #########
    #     # drag and drop 
    #     #########
        
    #     def on_drag_start(event):
    #         index = event.widget.curselection()
    #         if index:
    #             data = event.widget.get(index[0])
    #             event.widget.drag_data = data

    #     def on_drag_drop(event):
    #         target = event.widget
    #         data = event.widget.drag_data

    #         if target == listbox_supplier_consolidated:
    #             index = listbox_supplier_consolidated.nearest(event.y)
    #             item = listbox_supplier_consolidated.get(index)
    #             mappings[item] = data
    #             messagebox.showinfo("Mapping", f"Mapping created: {item} -> {data}")
    #         elif target == listbox_supplier:
    #             index = listbox_supplier.nearest(event.y)
    #             item = listbox_supplier.get(index)
    #             mappings[data] = item
    #             messagebox.showinfo("Mapping", f"Mapping created: {data} -> {item}")

    #     def on_drag_motion(event):
    #         widget = event.widget
    #         index = widget.nearest(event.y)

    #         if index < widget.start_drag_index:
    #             y = event.y - 15
    #         else:
    #             y = event.y + 15

    #         widget.coords(widget.drag_indicator, 0, y)

    #     def on_listbox_select(event):
    #         widget = event.widget
    #         widget.start_drag_index = widget.nearest(event.y)
    #         widget.drag_data = widget.get(widget.start_drag_index)

    #     # Bind events
    #     listbox_supplier.bind('<<ListboxSelect>>', on_listbox_select)
    #     listbox_supplier.bind('<B1-Motion>', on_drag_motion)
    #     listbox_supplier_consolidated.bind('<<ListboxDrop>>', on_drag_drop)

    #     # Create drag indicator
    #     listbox_supplier.drag_indicator = tk.Label(window, text="", relief=tk.RAISED, borderwidth=2)
    #     listbox_supplier.drag_indicator.place(x=0, y=0)
    #     # refresh_button = tk.Button(window, text="Refresh", command=populate_listbox)
    #     # refresh_button.pack()


    #     # global variable1
    #     # global variable2       
    #     # # supplier_consolidated_copy = supplier_consolidated[:]

    #     # def map_elements(event = None):

    #     #     selected_option1 = variable1.get()
    #     #     selected_option2 = variable2.get()
    #     #     if ( selected_option2 != "Select Mapping Option" and selected_option1 != "Select Mapping Option" ):
    #     #         mappings[selected_option1] = selected_option2
    #     #     # option_menu1['menu'].delete(option_menu1['menu'].index(selected_option1))
    #     #     # option_menu2['menu'].delete(option_menu2['menu'].index(selected_option2))
    #     #     variable1.set("Select Mapping Option")
    #     #     variable2.set("Select Mapping Option")
    #     #     update_mappings_display()
    #     #     # print(mappings)  # You can replace this with your desired action            

    #     # def update_mappings_display():
    #     #     mappings_text.delete(0, tk.END)  # Clear previous mappings
    #     #     # print ( "I am here" )
    #     #     for element1, element2 in mappings.items():
    #     #         mapping_text1 = f"{element1} => {element2}"
    #     #         mappings_text.insert(tk.END,mapping_text1)
    
    #     # list1 = supplier_consolidated[:]
    #     # options1 = list1
    #     # variable1 = tk.StringVar(window)
    #     # variable1.set("Select Mapping Option")
    #     # print (variable1)
    #     # option_menu1 = tk.OptionMenu(window, variable1, *options1)
    #     # option_menu1.grid(row=3, column=0, columnspan=2, sticky="n")
        
    #     # list_suppliers = supplier_colums[:]
    #     # options2 =  list_suppliers
    #     # variable2 = tk.StringVar(window)
    #     # variable2.set("Select Mapping Option")

    #     # option_menu2 = tk.OptionMenu(window, variable2, *options2)
    #     # option_menu2.grid(row=3, column=2, columnspan=3, sticky="n")

    #     # btn_map = tk.Button(window, text="Map", command=map_elements)
    #     # btn_map.grid(row=3, column=1, columnspan=1, padx=10)
        
    #     # lbl_saved_successfully = tk.Label(window, text="saved sucessfully", font=("Arial", 18))
    #     # lbl_saved_successfully.grid(row=6, column=0, columnspan=3, padx=10, pady=5)

        
    #     # btn_generate_xlsx = tk.Button(window, text="Generate Excel File", command=lambda: generate_mapped_excel_file(mappings, data_list, supplier_colums))
    #     # btn_generate_xlsx.grid(row=5, column=1, columnspan=1)
    #     # mappings_text = tk.Listbox(window, width=60, height=36)
    #     # mappings_text.grid(row=4, column=0, columnspan=3, padx=10, pady=10)
    #     # window.bind('<Return>', map_elements)

    #     # update_mappings_display()
    # elif selected_option == "Generate Address File":
    #     # btn_next.config(state=tk.DISABLED)
    #     # # Open mapping window for Option 1
    #     # lbl_title.grid_forget()
    #     # option_menu.grid_forget()
    #     # btn_next.grid_forget()
    #     # btn_upload.grid_forget()
    #     # Configure row and column to expand and fill available space
    #     window.grid_rowconfigure(0, weight=1)
    #     window.grid_rowconfigure(5, weight=1)
    #     window.grid_columnconfigure(0, weight=1)
    #     window.grid_columnconfigure(2, weight=1)

    #     # Create UI elements for mapping
    #     lbl_option2 = tk.Label(window, text="Mapping to Generate Address File ")
    #     lbl_option2.grid(row=0, column=0, columnspan=3, sticky = "n")
    #     # Store the mappings in a dictionary
    #     mappings = {}
    #     global variable3
    #     global variable4      
    #     # supplier_consolidated_copy = supplier_consolidated[:]

    #     def map_elements(event = None):

    #         selected_option1 = variable3.get()
    #         selected_option2 = variable4.get()
    #         if ( selected_option2 != "Select Mapping Option" and selected_option1 != "Select Mapping Option" ):
    #             mappings[selected_option1] = selected_option2
    #         # option_menu1['menu'].delete(option_menu1['menu'].index(selected_option1))
    #         # option_menu2['menu'].delete(option_menu2['menu'].index(selected_option2))
    #         variable3.set("Select Mapping Option")
    #         variable4.set("Select Mapping Option")
    #         update_mappings_display()
    #         # print(mappings)  # You can replace this with your desired action            

    #     def update_mappings_display():
    #         mappings_text.delete(0, tk.END)  # Clear previous mappings
    #         # print ( "I am here" )
    #         for element1, element2 in mappings.items():
    #             mapping_text1 = f"{element1} => {element2}"
    #             mappings_text.insert(tk.END,mapping_text1)
    
    #     list1 = supplier_consolidated[:]
    #     options1 = list1
    #     variable3 = tk.StringVar(window)
    #     variable3.set("Select Mapping Option")

    #     option_menu1 = tk.OptionMenu(window, variable3, *options1)
    #     option_menu1.grid(row=3, column=0, columnspan=2, sticky="n")

    #     list_suppliers_address = supplier_address[:]
    #     options2 =  list_suppliers_address
    #     variable4 = tk.StringVar(window)
    #     variable4.set("Select Mapping Option")

    #     option_menu2 = tk.OptionMenu(window, variable4, *options2)
    #     option_menu2.grid(row=3, column=2, columnspan=3, sticky="n")

    #     btn_map = tk.Button(window, text="Map", command=map_elements)
    #     btn_map.grid(row=3, column=1, columnspan=1, padx=10)
        
    #     lbl_saved_successfully = tk.Label(window, text="", font=("Arial", 18))
    #     lbl_saved_successfully.grid(row=6, column=0, columnspan=3, padx=10, pady=5)

    #     btn_generate_xlsx = tk.Button(window, text="Generate Excel File", command=lambda: generate_mapped_excel_file(mappings, data_list, supplier_address))
    #     btn_generate_xlsx.grid(row=5, column=1, columnspan=1)
    #     mappings_text = tk.Listbox(window, width=60, height=36)
    #     mappings_text.grid(row=4, column=0, columnspan=3, padx=10, pady=10)
    #     window.bind('<Return>', map_elements)

    #     update_mappings_display()
    # elif selected_option == "Generate Supplier Site Data File":
    #     # btn_next.config(state=tk.DISABLED)
    #     # # Open mapping window for Option 1
    #     # lbl_title.grid_forget()
    #     # option_menu.grid_forget()
    #     # btn_next.grid_forget()
    #     # btn_upload.grid_forget()
    #     # Configure row and column to expand and fill available space
    #     window.grid_rowconfigure(0, weight=1)
    #     window.grid_rowconfigure(5, weight=1)
    #     window.grid_columnconfigure(0, weight=1)
    #     window.grid_columnconfigure(2, weight=1)

    #     # Create UI elements for mapping
    #     lbl_option3 = tk.Label(window, text="Mapping to Generate Supplier Site Data File")
    #     lbl_option3.grid(row=0, column=0, columnspan=3, sticky = "n")
    #     # Store the mappings in a dictionary
    #     mappings = {}
    #     print (mappings)
    #     global variable5
    #     global variable6      
    #     # supplier_consolidated_copy = supplier_consolidated[:]

    #     def map_elements(event = None):

    #         selected_option1 = variable5.get()
    #         selected_option2 = variable6.get()
    #         if ( selected_option2 != "Select Mapping Option" and selected_option1 != "Select Mapping Option" ):
    #             mappings[selected_option1] = selected_option2
    #         # option_menu1['menu'].delete(option_menu1['menu'].index(selected_option1))
    #         # option_menu2['menu'].delete(option_menu2['menu'].index(selected_option2))
    #         variable5.set("Select Mapping Option")
    #         variable6.set("Select Mapping Option")
    #         update_mappings_display()
    #         # print(mappings)  # You can replace this with your desired action            

    #     def update_mappings_display():
    #         mappings_text.delete(0, tk.END)  # Clear previous mappings
    #         # print ( "I am here" )
    #         for element1, element2 in mappings.items():
    #             mapping_text1 = f"{element1} => {element2}"
    #             mappings_text.insert(tk.END,mapping_text1)
    
    #     list1 = supplier_consolidated[:]
    #     options1 = list1
    #     variable5 = tk.StringVar(window)
    #     variable5.set("Select Mapping Option")

    #     option_menu1 = tk.OptionMenu(window, variable5, *options1)
    #     option_menu1.grid(row=3, column=0, columnspan=2, sticky="n")
        
    #     list_suppliers_site_data = supplier_site_data[:]
    #     options2 =  list_suppliers_site_data
    #     variable6 = tk.StringVar(window)
    #     variable6.set("Select Mapping Option")

    #     option_menu2 = tk.OptionMenu(window, variable6, *options2)
    #     option_menu2.grid(row=3, column=2, columnspan=3, sticky="n")

    #     btn_map = tk.Button(window, text="Map", command=map_elements)
    #     btn_map.grid(row=3, column=1, columnspan=1, padx=10)
        
    #     lbl_saved_successfully = tk.Label(window, text="", font=("Arial", 18))
    #     lbl_saved_successfully.grid(row=6, column=0, columnspan=3, padx=10, pady=5)

    #     btn_generate_xlsx = tk.Button(window, text="Generate Excel File", command=lambda: generate_mapped_excel_file(mappings, data_list, supplier_site_data))
    #     btn_generate_xlsx.grid(row=5, column=1, columnspan=1)
    #     mappings_text = tk.Listbox(window, width=60, height=36)
    #     mappings_text.grid(row=4, column=0, columnspan=3, padx=10, pady=10)
    #     window.bind('<Return>', map_elements)

    #     update_mappings_display()

    # else:
    #     messagebox.showerror("Error", "Invalid option selected.")