from PIL import Image, ImageDraw

# Create a new image with a transparent background
width = 300
height = 300
image = Image.new("RGBA", (width, height), (0, 0, 0, 0))

# Create a drawing context
draw = ImageDraw.Draw(image)

# Define the parameters for the rounded rectangle
x = 50
y = 50
rectangle_width = 315
rectangle_height = 320
corner_radius = 20
fill_color = "#f5f4f2"  # RGBA value for red (fully opaque)

# Draw the rounded rectangle with the specified fill color
draw.rounded_rectangle(
    [(x, y), (x + rectangle_width, y + rectangle_height)],
    corner_radius,
    fill=fill_color,
    outline=None  # Set outline to None for no outline
)

# Save the image as a PNG file
image.save("rounded_page1.png", "PNG")
